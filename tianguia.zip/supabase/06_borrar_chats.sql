-- =====================================================================
-- TianGuía · Borrar conversaciones (solo para quien las borra)
-- Ejecutar en Supabase > SQL Editor. Es re-ejecutable.
-- No se borran mensajes de verdad: así la otra persona conserva su chat
-- y los reportes (RF-44) siguen teniendo evidencia.
-- =====================================================================
create table if not exists public.conversaciones_ocultas (
  id_usuario      uuid not null references public.usuarios(id) on delete cascade,
  id_conversacion uuid not null references public.conversaciones(id) on delete cascade,
  ocultada_en     timestamptz not null default now(),
  primary key (id_usuario, id_conversacion)
);

alter table public.conversaciones_ocultas enable row level security;

drop policy if exists tg_ocultas_propias on public.conversaciones_ocultas;
create policy tg_ocultas_propias on public.conversaciones_ocultas
  for all to authenticated
  using (id_usuario = auth.uid())
  with check (id_usuario = auth.uid());

grant select, insert, update, delete on public.conversaciones_ocultas to authenticated;

-- Oculta (o vuelve a ocultar) la conversación usando la hora del servidor.
create or replace function public.ocultar_conversacion(p_id uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.soy_de_conversacion(p_id) then
    raise exception 'No participas en esa conversación';
  end if;
  insert into public.conversaciones_ocultas (id_usuario, id_conversacion, ocultada_en)
  values (auth.uid(), p_id, now())
  on conflict (id_usuario, id_conversacion) do update set ocultada_en = now();
end $$;

grant execute on function public.ocultar_conversacion(uuid) to authenticated;
